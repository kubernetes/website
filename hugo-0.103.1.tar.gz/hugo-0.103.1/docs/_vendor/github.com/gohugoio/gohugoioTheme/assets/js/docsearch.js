var docsearch = require('docsearch.js/dist/cdn/docsearch.js');
docsearch({
  apiKey: '167e7998590aebda7f9fedcf86bc4a55',
  indexName: 'hugodocs',
  inputSelector: '#search-input',
  debug: true // Set debug to true if you want to inspect the dropdown
});
