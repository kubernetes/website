---
title: lt
linktitle: lt
description: Returns the boolean truth of arg1 < arg2.
date: 2017-07-26
publishdate: 2017-07-26
lastmod: 2017-07-26
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [operators,logic]
signature: ["lt ARG1 ARG2"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---


```
{{ if lt 5 10 }}true{{ end }}
```
