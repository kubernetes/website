---
title: .HasChildren
description:
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [menus]
toc:
signature: ["HasChildren"]
workson: [menus]
hugoversion:
relatedfuncs: []
deprecated: false
draft: true
aliases: []
---

Used in [menu templates](/templates/menu-templates/).
